 const tripulantes = [
  {
    id: 1,
    nombre: 'odaris',
    salario: 89999
  },
  {
     id: 2,
     nombre: 'jhan carlos',
     salario: 600000
  },
  {
     id: 3,
     nombre: 'pedro emilio',
     salario: 600000
  },
  {
   id: 4,
   nombre: 'Claudia PAtricia',
   salario: 600000
  },

];// fin de estructura de datos tripulantes
export default tripulantes;


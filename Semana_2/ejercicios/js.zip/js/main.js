// palabra clave + nombre estructura datos + ubicación del archivo con los datos
import tripulantes  from './datos/data.js'; //importando un arreglo de objetos

// export const nombreFuncion = (listaParametro) =>^{ cuerpo de la función.}            
export const busquedaPorId = (paramID) => {
         //arreglo_objeto.find ( (nombre_objeto resultante)) ==> c/u obj arreglo == parametro de la función
  return tripulantes.find((objTripulante)=> objTripulante.id==paramID)

}// fin de la función busqueda por id
// export const nombreFuncion = (listaParametro) =>^{ cuerpo de la función.}  
export const busquedaPorSalario = (paramSalario)=>{
    //                     tipo de objeto --> crieterio de comparación                        
    //arreglo_objeto.find ( (nombre_objeto resultante)) ==> c/u obj arreglo == parametro de la función
    return tripulantes.find(  (objTripulante) => objTripulante.salario==paramSalario   )
}

console.log("El tripulante con ID 1 es:"+busquedaPorId(1).nombre);

// busqueda de tripulante por salarios
console.log(' El tripulante con salario 600000 es:'+busquedaPorSalario(600000).nombre);

// filtre y ordene por nombres
const filtreSalario = ( salario ) => tripulantes.filter((tripulante) => tripulante.salario == salario);
console.log('objetos',filtreSalario (600000));



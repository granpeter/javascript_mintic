//var numero=560;
var letrero = " El dicho dice \"El que peca y reza empata\" "
//var numero2=562;
//let resultado=numero+numero2;
var numero$1=7878;
 //console.log (numero)
 /*console.log ("VAr numero2"+numero2)
 alert (letrero);
 console.log ("Reasignado tipos de variables")
 console.log ("VAr numero2 luego de la reasignacion"+numero2)
 console.log("cambiando tipo de datos:"+numero2) //ESte codigo tiene la contraseña
*/

 let arreglo =[1,2,"tres",4,"cinco",true,false];
 console.log (arreglo)

      if (arreglo[0]=="uno"){
        alert(" El valor del arreglo es una cadena de texto")
       }else if (arreglo[0]==1){
        alert(" El valor del arreglo es un número")
       }

     /*
       
     */ 
sumar();

function sumar(){
 
 
  
  for (i in arreglo){
    alert("la posicion "+i+" del arreglo es:"+arreglo[i])
    var numero=89;
    var numero2=90;
    var resultado;
   
 
}// fin de sentecia if
resultado=numero+numero2;
alert("El resultado dentro de la función es:"+resultado)  


}

//alert ("El resulta de numero+número2 es:"+resultado)

       